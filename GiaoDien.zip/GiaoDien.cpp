#include <SFML/Graphics.hpp>
#include "GiaoDien/QuanLyGiaoDien.h"
#include "NhanVat/NguoiChoi.h"

int main() {
    sf::RenderWindow window(sf::VideoMode(sf::Vector2u(1280, 720)), "Bach Dang 938");
    window.setFramerateLimit(60);

    // Khởi tạo Nhân vật của Tuấn và UI của Ngân
    NguoiChoi player(400.f, 300.f);
    QuanLyGiaoDien uiManager;
    uiManager.KhoiTao(1280.f, 720.f, "TaiNguyen/PhongChu/font_game.ttf");

    sf::Clock clock;

    while (window.isOpen()) {
        float dt = clock.restart().asSeconds();

        while (const auto event = window.pollEvent()) {
            if (event->is<sf::Event::Closed>()) {
                window.close();
            }
            // Truyền event chuột sang UI Manager
            uiManager.XuLySuKien(*event, window);
        }

        // Nếu đang trong game thì cập nhật NguoiChoi
        if (uiManager.GetTrangThai() == TrangThaiUI::DANG_CHOI) {
            player.XuLyPhim();
            player.CapNhat(dt);
        }

        // Cập nhật giao diện (tự động đọc máu, thể lực, số cọc từ player)
        uiManager.CapNhat(window, player);

        // Vẽ
        window.clear(sf::Color(35, 45, 60));

        if (uiManager.GetTrangThai() == TrangThaiUI::DANG_CHOI) {
            player.Ve(window); // Vẽ nhân vật
        }
        uiManager.Ve(window);  // Vẽ HUD hoặc Menu đè lên trên

        window.display();
    }

    return 0;
}
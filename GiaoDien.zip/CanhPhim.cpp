#include <SFML/Graphics.hpp>
#include "CanhPhim/QuanLyCanhPhim.h"

int main() {
    const float W = 800.f;
    const float H = 600.f;
    sf::RenderWindow window(sf::VideoMode(W, H), "Test Cinematic - Rung Man Hinh");
    window.setFramerateLimit(60);

    // Khởi tạo Camera (View)
    sf::View viewGame(sf::FloatRect(0.f, 0.f, W, H));
    sf::Vector2f viTriGoc(W / 2.f, H / 2.f);

    // Khởi tạo Trình cắt cảnh
    QuanLyCanhPhim canhPhim;
    canhPhim.KhoiTaoAmThanh("TaiNguyen/AmThanh/crash.wav");

    // Tạo vật thể trực quan để dễ thấy hiệu ứng rung
    sf::RectangleShape tauDich(sf::Vector2f(120.f, 60.f));
    tauDich.setFillColor(sf::Color(160, 82, 45)); // Nâu gỗ
    tauDich.setPosition(340.f, 270.f);

    sf::CircleShape cocGo(15.f);
    cocGo.setFillColor(sf::Color::White);
    cocGo.setPosition(400.f, 260.f);

    sf::Clock clock;
    TrangThaiTranDau trangThaiHienTai = TrangThaiTranDau::CHUAN_BI;

    while (window.isOpen()) {
        float dt = clock.restart().asSeconds();
        sf::Event event;

        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                window.close();

            if (event.type == sf::Event::KeyPressed) {
                // Nhấn phím 5 để kích hoạt sự kiện Tàu Mắc Cọc
                if (event.key.code == sf::Keyboard::Num5 || event.key.code == sf::Keyboard::Numpad5) {
                    trangThaiHienTai = TrangThaiTranDau::TAU_MAC_COC;
                    canhPhim.CapNhatTrangThai(trangThaiHienTai);
                }
                // Nhấn phím 1 để reset lại chuẩn bị
                if (event.key.code == sf::Keyboard::Num1 || event.key.code == sf::Keyboard::Numpad1) {
                    trangThaiHienTai = TrangThaiTranDau::CHUAN_BI;
                    canhPhim.CapNhatTrangThai(trangThaiHienTai);
                }
            }
        }

        // Cập nhật camera
        canhPhim.CapNhat(dt, viewGame, viTriGoc);

        window.clear(sf::Color(24, 76, 120)); // Màu nước sông

        // Áp dụng view vừa rung lên màn hình để vẽ
        window.setView(viewGame);
        window.draw(tauDich);
        window.draw(cocGo);

        window.display();
    }

    return 0;
}
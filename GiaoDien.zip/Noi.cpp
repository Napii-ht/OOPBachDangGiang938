#pragma once
#include <SFML/Graphics.hpp>
#include "MenuChinh.h"
#include "ThanhMau.h"
#include "../NhanVat/NguoiChoi.h"

enum class TrangThaiUI {
    MENU,
    DANG_CHOI,
    KET_THUC
};

class QuanLyGiaoDien {
private:
    TrangThaiUI trangThaiHienTai;
    MenuChinh menuChinh;

    // HUD (In-game)
    ThanhMau thanhMau;
    ThanhMau thanhTheLuc;
    sf::Font font;
    sf::Text textChiSo;
    sf::Text textSoCoc;

public:
    QuanLyGiaoDien() : trangThaiHienTai(TrangThaiUI::MENU) {}

    void KhoiTao(float screenW, float screenH, const std::string& fontPath) {
        font.openFromFile(fontPath);

        // Khởi tạo menu chính
        menuChinh.KhoiTao(screenW, screenH, fontPath);

        // Khởi tạo HUD: Thanh máu đỏ (x: 20, y: 20), Thể lực xanh lục (x: 20, y: 50)
        thanhMau = ThanhMau(20.f, 20.f, 200.f, 20.f, sf::Color(220, 20, 60));
        thanhTheLuc = ThanhMau(20.f, 48.f, 150.f, 12.f, sf::Color(50, 205, 50));

        // Nhãn chỉ số
        textChiSo.setFont(font);
        textChiSo.setCharacterSize(14);
        textChiSo.setFillColor(sf::Color::White);
        textChiSo.setPosition(sf::Vector2f(20.f, 65.f));

        // Hiển thị số cọc thu thập từ NguoiChoi (Góc trên bên phải)
        textSoCoc.setFont(font);
        textSoCoc.setCharacterSize(18);
        textSoCoc.setFillColor(sf::Color(255, 215, 0));
        textSoCoc.setPosition(sf::Vector2f(screenW - 220.f, 20.f));
    }

    TrangThaiUI GetTrangThai() const { return trangThaiHienTai; }
    void SetTrangThai(TrangThaiUI tt) { trangThaiHienTai = tt; }

    // Xử lý sự kiện chuột cho UI
    void XuLySuKien(const sf::Event& event, const sf::RenderWindow& window) {
        if (trangThaiHienTai == TrangThaiUI::MENU) {
            if (event.is<sf::Event::MouseButtonPressed>()) {
                const auto* mouseBtn = event.getIf<sf::Event::MouseButtonPressed>();
                if (mouseBtn && mouseBtn->button == sf::Mouse::Button::Left) {
                    LuaChonMenu chon = menuChinh.XuLyClick(sf::Mouse::getPosition(window));
                    if (chon == LuaChonMenu::BAT_DAU) {
                        trangThaiHienTai = TrangThaiUI::DANG_CHOI;
                    }
                    else if (chon == LuaChonMenu::THOAT) {
                        exit(0);
                    }
                }
            }
        }
    }

    // CẬP NHẬT HUD: Lấy trực tiếp dữ liệu từ class NguoiChoi của Tuấn
    void CapNhat(sf::RenderWindow& window, const NguoiChoi& player) {
        if (trangThaiHienTai == TrangThaiUI::MENU) {
            menuChinh.CapNhat(sf::Mouse::getPosition(window));
        }
        else if (trangThaiHienTai == TrangThaiUI::DANG_CHOI) {
            // Lấy máu (sucKhoe kế thừa từ NhanVat) và thể lực từ NguoiChoi
            thanhMau.CapNhat(static_cast<float>(player.GetSucKhoe()), static_cast<float>(player.GetSucKhoeToiDa()));
            thanhTheLuc.CapNhat(player.GetTheLuc(), player.GetTheLucToiDa());

            // Cập nhật text số cọc gỗ đã nhặt
            std::string cocStr = u8"Cọc gỗ: " + std::to_string(player.GetSoLuongCoc()) + "/3";
            if (player.DaThuThapDu3Coc()) {
                cocStr += u8" (Đủ cọc!)";
            }
            textSoCoc.setString(sf::String::fromUtf8(cocStr.begin(), cocStr.end()));
        }
    }

    // Vẽ toàn bộ giao diện
    void Ve(sf::RenderWindow& window) {
        if (trangThaiHienTai == TrangThaiUI::MENU) {
            menuChinh.Ve(window);
        }
        else if (trangThaiHienTai == TrangThaiUI::DANG_CHOI) {
            thanhMau.Ve(window);
            thanhTheLuc.Ve(window);
            window.draw(textSoCoc);
        }
    }
};